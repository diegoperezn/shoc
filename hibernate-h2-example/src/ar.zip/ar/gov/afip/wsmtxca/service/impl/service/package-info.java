@javax.xml.bind.annotation.XmlSchema(namespace = "http://impl.service.wsmtxca.afip.gov.ar/service/")
package ar.gov.afip.wsmtxca.service.impl.service;
